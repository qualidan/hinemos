from requests import Session
from requests.auth import HTTPBasicAuth
from zeep import Client
from zeep.transports import Transport

username=""
password=""
ip=""

jobWM=1
jobWT=1

session = Session()
session.auth = HTTPBasicAuth(username, password)

client = Client("http://"+ip+":8080/HinemosWS/JobEndpoint?wsdl",
                        transport=Transport(session=session))

factory = client.type_factory('http://jobmanagement.ws.clustercontrol.com')

out = factory.outputBasicInfo()
trig = factory.jobTriggerInfo()
trig.trigger_type = 2
trig.trigger_info = username

out.priority = 0
trig.jobCommand = ""
trig.jobWaitMinute = jobWM
trig.jobWaitTime = jobWT

