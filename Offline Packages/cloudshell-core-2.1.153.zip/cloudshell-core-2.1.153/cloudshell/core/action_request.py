class ActionRequest(object):
    def __init__(self):
        self.actionId = ''
        self.type = ''
        self.actionTarget = None
        self.connectioId = ''
        self.connectionParams = []
