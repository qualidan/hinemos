class ActionResult(object):

    def __init__(self):
        self.actionId = '',
        self.type = '',
        self.infoMessage = '',
        self.errorMessage = '',
        self.success = True,
        self.updatedInterface = ''
