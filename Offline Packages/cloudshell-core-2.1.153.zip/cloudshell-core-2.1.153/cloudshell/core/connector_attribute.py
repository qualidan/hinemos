class ConnectorAttribute(object):
    def __init__(self):
        self.type = ''
        self.attributeName = ''
        self.attributeValue = ''
