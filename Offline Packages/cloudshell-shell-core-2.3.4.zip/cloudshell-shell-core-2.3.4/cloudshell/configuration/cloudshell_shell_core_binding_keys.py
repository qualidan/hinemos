"""Binding keys"""

"""Config binding key"""
CONFIG = 'config'

"""Context binding key"""
CONTEXT = 'context'

"""Logger binding key"""
LOGGER = 'logger'

"""Cloudshell API binding key"""
API = 'api'
