import sys

file = open("hinemostestfile.txt", "w")

file.write("Number of arguments: ", len(sys.argv))
file.write("The arguments are: ", str(sys.argv))

file.close()
